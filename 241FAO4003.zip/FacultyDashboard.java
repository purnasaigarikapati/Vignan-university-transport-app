package com.vignan.ui;

import javax.swing.*;
import java.awt.*;

public class FacultyDashboard extends JFrame {

    public FacultyDashboard(String username) {
        setTitle("Faculty Dashboard - " + username);
        setSize(620, 420);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        JLabel header = new JLabel("Vignan University - Faculty Dashboard", SwingConstants.CENTER);
        header.setBounds(0, 0, 620, 50);
        header.setOpaque(true);
        header.setBackground(new Color(18,61,140));
        header.setForeground(Color.WHITE);
        header.setFont(new Font("SansSerif", Font.BOLD, 18));
        add(header);

        // For simplicity, reuse Student dashboard layout controls
        JButton traceBtn = new JButton("<html><u>Open Bus Tracing (web.dhundhoo.com/live)</u></html>");
        traceBtn.setBounds(30, 70, 330, 30);
        traceBtn.setBorderPainted(false);
        traceBtn.setContentAreaFilled(false);
        traceBtn.setForeground(new Color(0,102,204));
        traceBtn.addActionListener(e -> openURL("https://web.dhundhoo.com/live"));
        add(traceBtn);

        JButton searchBtn = new JButton("Search Bus");
        searchBtn.setBounds(30, 120, 120, 30);
        searchBtn.addActionListener(e -> new BusSearchPage());
        add(searchBtn);

        JButton payBtn = new JButton("Pay Bus Fee");
        payBtn.setBounds(30, 170, 120, 30);
        payBtn.addActionListener(e -> new FeePaymentPage());
        add(payBtn);

        // Add a text field for bus number and a track button
        JTextField busNumberField = new JTextField();
        busNumberField.setBounds(30, 220, 120, 30);
        add(busNumberField);

        JButton trackByNumberBtn = new JButton("Track by Number");
        trackByNumberBtn.setBounds(160, 220, 150, 30);
        trackByNumberBtn.addActionListener(e -> {
            String busNumber = busNumberField.getText().trim();
            if (!busNumber.isEmpty()) {
                // Assuming the tracking URL can be modified to include bus number, e.g., appending it as a query param
                openURL("https://web.dhundhoo.com/live?bus=" + busNumber);
            } else {
                JOptionPane.showMessageDialog(this, "Please enter a bus number.");
            }
        });
        add(trackByNumberBtn);

        setVisible(true);
    }

    private void openURL(String url) {
        try { java.awt.Desktop.getDesktop().browse(new java.net.URI(url)); }
        catch (Exception ex) { JOptionPane.showMessageDialog(this, "Unable to open link: " + ex.getMessage()); }
    }
}
