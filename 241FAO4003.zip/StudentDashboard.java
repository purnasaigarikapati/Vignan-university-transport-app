package com.vignan.ui;

import javax.swing.*;
import java.awt.*;

public class StudentDashboard extends JFrame {

    private boolean menuOpen = false;
    private JPanel menuPanel;

    public StudentDashboard(String username) {

        setTitle("Student Dashboard - " + username);
        setSize(750, 520);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel bg = new JPanel(null);
        bg.setBackground(new Color(230, 240, 255));
        add(bg);

        // ---------------- HEADER ----------------
        JLabel header = new JLabel("Vignan University - Student Dashboard", SwingConstants.CENTER);
        header.setBounds(0, 0, 750, 60);
        header.setOpaque(true);
        header.setBackground(new Color(18, 61, 140));
        header.setForeground(Color.WHITE);
        header.setFont(new Font("SansSerif", Font.BOLD, 20));
        bg.add(header);
        header.setLayout(null);

        // ---------------- MENU ICON (3 DASHES) ----------------
        JButton menuIcon = new JButton("☰");
        menuIcon.setBounds(10, 10, 40, 40);
        menuIcon.setFont(new Font("SansSerif", Font.BOLD, 22));
        menuIcon.setFocusPainted(false);
        menuIcon.setBackground(Color.WHITE);
        header.add(menuIcon);

        // ---------------- POPUP MENU PANEL (HIDDEN) ----------------
        menuPanel = new JPanel(null);
        menuPanel.setBounds(10, 60, 160, 120);
        menuPanel.setBackground(new Color(45, 45, 45));
        menuPanel.setVisible(false);
        bg.add(menuPanel);

        JLabel menuTitle = new JLabel("Quick Login", SwingConstants.CENTER);
        menuTitle.setBounds(0, 0, 160, 25);
        menuTitle.setForeground(Color.WHITE);
        menuTitle.setFont(new Font("SansSerif", Font.BOLD, 12));
        menuPanel.add(menuTitle);

        JButton driverBtn = new JButton("Driver Login");
        driverBtn.setBounds(10, 30, 140, 35);
        driverBtn.setBackground(new Color(70, 130, 180));
        driverBtn.setForeground(Color.WHITE);
        menuPanel.add(driverBtn);

        driverBtn.addActionListener(e -> {
            menuPanel.setVisible(false);
            new LoginPage();
            JOptionPane.showMessageDialog(null, "Switch to Driver Login");
        });

        JButton facultyBtn = new JButton("Faculty Login");
        facultyBtn.setBounds(10, 75, 140, 35);
        facultyBtn.setBackground(new Color(46, 139, 87));
        facultyBtn.setForeground(Color.WHITE);
        menuPanel.add(facultyBtn);

        facultyBtn.addActionListener(e -> {
            menuPanel.setVisible(false);
            new LoginPage();
            JOptionPane.showMessageDialog(null, "Switch to Faculty Login");
        });

        // MENU ICON CLICK → SHOW/HIDE PANEL
        menuIcon.addActionListener(e -> {
            menuOpen = !menuOpen;
            menuPanel.setVisible(menuOpen);
        });

        // ------ STUDENT PORTAL BUTTON ------
        JButton portalBtn = new JButton("Student Portal");
        portalBtn.setBounds(450, 15, 130, 30);
        portalBtn.setBackground(new Color(255, 153, 0));
        portalBtn.setForeground(Color.WHITE);
        portalBtn.setFont(new Font("SansSerif", Font.BOLD, 12));
        header.add(portalBtn);

        portalBtn.addActionListener(e -> openURL("http://160.187.169.12/student/"));

        // ------ LOGOUT BUTTON ------
        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setBounds(600, 15, 110, 30);
        logoutBtn.setBackground(new Color(204, 51, 51));
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setFont(new Font("SansSerif", Font.BOLD, 12));
        header.add(logoutBtn);

        logoutBtn.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Logged out successfully!");
            dispose();
            new LoginPage();
        });

        // *** CENTER AREA CONSTANTS ***
        int centerX = (750 - 500) / 2;

        // ---------------- SEARCH AREA ----------------
        JLabel searchLbl = new JLabel("Search Bus by Number:");
        searchLbl.setBounds(centerX, 100, 180, 25);
        searchLbl.setFont(new Font("SansSerif", Font.BOLD, 13));
        bg.add(searchLbl);

        JTextField searchTf = new JTextField();
        searchTf.setBounds(centerX + 190, 100, 200, 28);
        bg.add(searchTf);

        JButton searchBtn = new JButton("Search");
        searchBtn.setBounds(centerX + 400, 100, 100, 28);
        searchBtn.setBackground(new Color(30, 144, 255));
        searchBtn.setForeground(Color.WHITE);
        bg.add(searchBtn);

        JButton traceBusBtn = new JButton("Trace Bus");
        traceBusBtn.setBounds(centerX + 510, 100, 120, 28);
        traceBusBtn.setBackground(new Color(0, 153, 76));
        traceBusBtn.setForeground(Color.WHITE);
        bg.add(traceBusBtn);

        traceBusBtn.addActionListener(e -> {
            String busNo = searchTf.getText().trim().toUpperCase();

            if (busNo.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter Bus Number!");
                return;
            }

            String dynamicURL =
                    "https://web.dhundhoo.com/live_singletrack?apiKey=2c76dd10-74d1-4798-bded-7b80ea1ecc6f&thingId=" + busNo;

            try {
                Desktop.getDesktop().browse(new java.net.URI(dynamicURL));
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });

        // ---------------- RESULT PANEL ----------------
        JPanel resultPanel = new JPanel(new BorderLayout());
        resultPanel.setBounds(centerX, 150, 500, 260);
        resultPanel.setBackground(Color.WHITE);
        resultPanel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        bg.add(resultPanel);

        JTextArea resultArea = new JTextArea();
        resultArea.setEditable(false);
        resultArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        resultPanel.add(resultArea);

        searchBtn.addActionListener(e -> {
            String busNo = searchTf.getText().trim().toUpperCase();
            if (busNo.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Enter bus number!");
                return;
            }
            new BusSearchPage(busNo, resultArea);
        });

        // ---------------- SIDE BUTTONS RIGHT SIDE ----------------
        JButton view3D = new JButton("<html><center>3D Map<br>View</center></html>");
        view3D.setBounds(centerX + 520, 180, 90, 90);
        view3D.setBackground(new Color(0, 153, 153));
        view3D.setForeground(Color.WHITE);
        bg.add(view3D);

        view3D.addActionListener(e -> openURL("https://www.google.com/maps/@?api=1&map_action=pano"));

        JButton paymentBtn = new JButton("<html><center>Online<br>Payment</center></html>");
        paymentBtn.setBounds(centerX + 520, 290, 90, 90);
        paymentBtn.setBackground(new Color(204, 102, 0));
        paymentBtn.setForeground(Color.WHITE);
        bg.add(paymentBtn);

        paymentBtn.addActionListener(e -> new FeePaymentPage());

        // ---------------- SEAT NO BUTTON ----------------
        JButton seatBtn = new JButton("<html><center>View<br>Seats</center></html>");
        seatBtn.setBounds(centerX + 520, 400, 90, 90);
        seatBtn.setBackground(new Color(102, 51, 204));
        seatBtn.setForeground(Color.WHITE);
        bg.add(seatBtn);

        seatBtn.addActionListener(e -> {
            String busNo = searchTf.getText().trim().toUpperCase();
            if (busNo.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter Bus Number to view seats!");
                return;
            }
            new BusSeatsPage(busNo); // Opens a page displaying seat arrangement
        });

        setVisible(true);
    }

    private void openURL(String url) {
        try {
            Desktop.getDesktop().browse(new java.net.URI(url));
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Unable to open link!");
        }
    }
}
