package com.vignan.ui;

import com.vignan.db.DBConnection;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;

public class DriverDashboard extends JFrame {

    public DriverDashboard(String username) {
        setTitle("Driver Dashboard - " + username);
        setSize(720, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        JLabel header = new JLabel("Driver Dashboard", SwingConstants.CENTER);
        header.setBounds(0, 0, 720, 50);
        header.setOpaque(true);
        header.setBackground(new Color(18, 61, 140));
        header.setForeground(Color.WHITE);
        header.setFont(new Font("SansSerif", Font.BOLD, 20));
        add(header);

        // ================= DRIVER DETAILS =================
        JTextArea infoArea = new JTextArea();
        infoArea.setBounds(20, 70, 660, 150);
        infoArea.setEditable(false);
        infoArea.setBorder(BorderFactory.createTitledBorder("Driver Details"));
        add(infoArea);
        loadDriverInfo(username, infoArea);

        // ================= SEARCH BUS SECTION =================
        JLabel searchLabel = new JLabel("Search Bus No:");
        searchLabel.setBounds(20, 230, 120, 25);
        add(searchLabel);

        JTextField busSearchField = new JTextField();
        busSearchField.setBounds(130, 230, 140, 25);
        add(busSearchField);

        JButton searchBtn = new JButton("Search");
        searchBtn.setBounds(280, 230, 90, 25);
        searchBtn.setBackground(new Color(255, 121, 0));
        searchBtn.setForeground(Color.WHITE);
        add(searchBtn);

        JButton trackerBtn = new JButton("Open Tracker");
        trackerBtn.setBounds(380, 230, 140, 25);
        trackerBtn.setBackground(new Color(18, 61, 140));
        trackerBtn.setForeground(Color.WHITE);
        add(trackerBtn);

        JTextArea busDetailsArea = new JTextArea();
        busDetailsArea.setBounds(20, 270, 660, 120);
        busDetailsArea.setEditable(false);
        busDetailsArea.setBorder(BorderFactory.createTitledBorder("Bus Details"));
        add(busDetailsArea);

        busDetailsArea.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                String txt = busDetailsArea.getText();
                if (txt.contains("Bus No:")) {
                    String busNo = txt.split("Bus No: ")[1].split("\n")[0];
                    openTracker(busNo);
                }
            }
        });

        // --------------- SEARCH BUTTON ACTION ----------------
        searchBtn.addActionListener(e -> {
            String busNo = busSearchField.getText().trim();
            if (busNo.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Enter Bus Number!");
            } else {
                searchBusDetails(busNo, busDetailsArea);
                // Automatically open tracker for searched bus
                openTracker(busNo);
            }
        });

        // --------------- TRACKER BUTTON ACTION ----------------
        trackerBtn.addActionListener(e -> {
            String busNo = busSearchField.getText().trim();
            if (busNo.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Enter Bus Number to track!");
            } else {
                openTracker(busNo);
            }
        });

        // ================= TIMETABLE SECTION =================
        JTextArea timetableArea = new JTextArea();
        timetableArea.setBounds(20, 400, 660, 170);
        timetableArea.setEditable(false);
        timetableArea.setBorder(BorderFactory.createTitledBorder("Bus Trip Timetable"));
        add(timetableArea);
        loadBusTimetable(timetableArea);

        setVisible(true);
    }

    // ---------------- OPEN TRACKER ----------------
    private void openTracker(String busNo) {
        try {
            // Replace bus number in the API URL
            String url = "https://web.dhundhoo.com/live_singletrack?apiKey=2c76dd10-74d1-4798-bded-7b80ea1ecc6f&thingId=" + busNo;
            Desktop.getDesktop().browse(new java.net.URI(url));
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Cannot open tracker link");
        }
    }

    // ---------------- LOAD DRIVER INFO ----------------
    private void loadDriverInfo(String username, JTextArea area) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM driver_info WHERE driver_name = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                StringBuilder sb = new StringBuilder();
                sb.append("Driver Name: ").append(rs.getString("driver_name")).append("\n");
                sb.append("Driver ID: ").append(rs.getString("driver_id")).append("\n");
                sb.append("Bus No: ").append(rs.getString("bus_no")).append("\n");
                sb.append("Monthly Salary: ₹").append(rs.getInt("salary")).append("\n");
                sb.append("Morning Trip: ").append(rs.getString("morning_trip")).append("\n");
                sb.append("Evening Trip: ").append(rs.getString("evening_trip")).append("\n");
                sb.append("Trips Per Day: ").append(rs.getInt("trips_per_day")).append("\n");
                sb.append("KM Per Day: ").append(rs.getInt("km_per_day")).append("\n");
                sb.append("Thumb Impression Today: ✔ Completed\n");
                area.setText(sb.toString());
            } else {
                area.setText("Driver details not found.");
            }

        } catch (Exception e) {
            area.setText("DB Error: " + e.getMessage());
        }
    }

    // ---------------- SEARCH BUS DETAILS ----------------
    private void searchBusDetails(String busNo, JTextArea area) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM driver_info WHERE bus_no = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, busNo);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                StringBuilder sb = new StringBuilder();
                sb.append("Bus No: ").append(rs.getString("bus_no")).append("\n");
                sb.append("Driver Name: ").append(rs.getString("driver_name")).append("\n");
                sb.append("Driver ID: ").append(rs.getString("driver_id")).append("\n");
                sb.append("Seat Capacity: 52\n");
                sb.append("Route: ").append(rs.getString("morning_trip"))
                        .append(" - ").append(rs.getString("evening_trip")).append("\n");
                sb.append("Trips Per Day: ").append(rs.getInt("trips_per_day")).append("\n");
                sb.append("KM Per Day: ").append(rs.getInt("km_per_day")).append("\n");
                sb.append("\n👉 Click on Bus No to open Live Tracker");
                area.setText(sb.toString());
            } else {
                area.setText("No bus found with Bus No: " + busNo);
            }

        } catch (Exception e) {
            area.setText("Error: " + e.getMessage());
        }
    }

    // ---------------- LOAD TIMETABLE ----------------
    private void loadBusTimetable(JTextArea area) {
        try (Connection conn = DBConnection.getConnection()) {
            // Sort trips by AM/PM time
            String sql = "SELECT * FROM bus_timetable ORDER BY bus_no, STR_TO_DATE(trip_time, '%h:%i %p')";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            StringBuilder sb = new StringBuilder();
            sb.append(String.format("%-12s %-10s %-30s\n", "Bus No", "Trip Time", "Route"));
            sb.append("-------------------------------------------------------------\n");

            while (rs.next()) {
                sb.append(String.format("%-12s %-10s %-30s\n",
                        rs.getString("bus_no"),
                        rs.getString("trip_time"),
                        rs.getString("route")));
            }

            area.setText(sb.toString());

        } catch (Exception e) {
            area.setText("Error Loading Timetable -> " + e.getMessage());
        }
    }
}
