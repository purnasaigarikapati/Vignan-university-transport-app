package com.vignan.ui;

import com.vignan.db.DBConnection;
import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class BusTimetable extends JFrame {

    public BusTimetable() {
        setTitle("Bus Timetable");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JTextArea timetableArea = new JTextArea();
        timetableArea.setEditable(false);
        timetableArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(timetableArea);
        add(scrollPane, BorderLayout.CENTER);

        loadTimetable(timetableArea);

        setVisible(true);
    }

    private void loadTimetable(JTextArea area) {
        try (Connection conn = DBConnection.getConnection()) {
            // Sort by bus_no and trip_time (AM/PM format)
            String sql = "SELECT * FROM bus_timetable ORDER BY bus_no, STR_TO_DATE(trip_time, '%h:%i %p')";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            StringBuilder sb = new StringBuilder();
            sb.append(String.format("%-12s %-10s %-30s\n", "Bus No", "Trip Time", "Route"));
            sb.append("-------------------------------------------------------------\n");

            String lastBus = "";
            while (rs.next()) {
                String busNo = rs.getString("bus_no");
                String tripTime = rs.getString("trip_time");
                String route = rs.getString("route");

                // Optional: separate buses visually
                if (!busNo.equals(lastBus)) {
                    if (!lastBus.isEmpty()) sb.append("\n");
                    lastBus = busNo;
                }

                sb.append(String.format("%-12s %-10s %-30s\n", busNo, tripTime, route));
            }

            area.setText(sb.toString());

        } catch (Exception e) {
            area.setText("Error Loading Timetable -> " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(BusTimetable::new);
    }
}
