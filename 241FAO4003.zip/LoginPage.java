package com.vignan.ui;

import com.vignan.db.DBConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginPage extends JFrame {

    private JTextField userField;
    private JPasswordField passField;
    private JComboBox<String> roleBox;

    public LoginPage() {

        setTitle("VIGNAN UNIVERSITY TRANSPORT");
        setSize(520, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // ------------ MAIN BACKGROUND PANEL ------------
        JPanel main = new JPanel(new GridBagLayout());
        main.setBackground(new Color(240, 240, 240));
        add(main);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);

        // ------------ CENTER CARD PANEL WITH SHADOW ------------
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(new Color(0, 0, 0, 50)); // soft shadow
                g2.fillRoundRect(5, 5, getWidth() - 10, getHeight() - 10, 25, 25);
                g2.dispose();
            }
        };

        card.setLayout(new GridBagLayout());
        card.setPreferredSize(new Dimension(380, 500));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        gbc.gridx = 0;
        gbc.gridy = 0;
        main.add(card, gbc);

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(10, 10, 10, 10);
        c.fill = GridBagConstraints.HORIZONTAL;

        // ------------ LOGO ------------
        JLabel logo = new JLabel(new ImageIcon("logo.png"));
        c.gridx = 0;
        c.gridy = 0;
        card.add(logo, c);

        // ------------ TITLE WITH BACKGROUND ------------
        JLabel heading = new JLabel("VIGNAN UNIVERSITY TRANSPORT", JLabel.CENTER);
        heading.setFont(new Font("Arial", Font.BOLD, 18));
        heading.setForeground(Color.WHITE);
        heading.setOpaque(true);
        heading.setBackground(new Color(0, 102, 204)); // blue highlight
        heading.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        c.gridy = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        card.add(heading, c);

        // ------------ USERNAME LABEL ------------
        JLabel userLabel = new JLabel("Username:");
        userLabel.setFont(new Font("Arial", Font.BOLD, 14));
        c.gridy = 2;
        card.add(userLabel, c);

        // ------------ USERNAME FIELD ------------
        userField = new JTextField(20);
        userField.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        userField.setFont(new Font("Arial", Font.PLAIN, 15));
        c.gridy = 3;
        card.add(userField, c);

        // ------------ PASSWORD LABEL ------------
        JLabel passLabel = new JLabel("Password:");
        passLabel.setFont(new Font("Arial", Font.BOLD, 14));
        c.gridy = 4;
        card.add(passLabel, c);

        // ------------ PASSWORD FIELD ------------
        passField = new JPasswordField(20);
        passField.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        passField.setFont(new Font("Arial", Font.PLAIN, 15));
        c.gridy = 5;
        card.add(passField, c);

        // ------------ ROLE LABEL ------------
        JLabel roleLabel = new JLabel("Select Role:");
        roleLabel.setFont(new Font("Arial", Font.BOLD, 14));
        c.gridy = 6;
        card.add(roleLabel, c);

        // ------------ ROLE BOX ------------
        roleBox = new JComboBox<>(new String[]{"Student", "Faculty", "Driver"});
        roleBox.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1));
        roleBox.setFont(new Font("Arial", Font.PLAIN, 15));
        c.gridy = 7;
        card.add(roleBox, c);

        // ------------ LOGIN BUTTON ------------
        JButton loginBtn = new JButton("LOGIN");
        loginBtn.setBackground(new Color(255, 153, 0));
        loginBtn.setForeground(Color.WHITE);
        loginBtn.setFont(new Font("Arial", Font.BOLD, 16));
        loginBtn.setFocusPainted(false);
        loginBtn.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));

        c.gridy = 8;
        c.ipady = 8;
        card.add(loginBtn, c);

        loginBtn.addActionListener((ActionEvent e) -> loginUser());

        setVisible(true);
    }

    // ------------ LOGIN METHOD ------------
    private void loginUser() {
        String username = userField.getText();
        String password = new String(passField.getPassword());
        String role = roleBox.getSelectedItem().toString();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter Username & Password");
            return;
        }

        try {
            Connection con = DBConnection.getConnection();
            String query = "SELECT * FROM users WHERE username=? AND password=? AND role=?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, username);
            ps.setString(2, password);
            ps.setString(3, role);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                JOptionPane.showMessageDialog(this, "Login Successful!");

                if (role.equals("Student")) {
                    new StudentDashboard(username);
                } else if (role.equals("Faculty")) {
                    new FacultyDashboard(username);
                } else if (role.equals("Driver")) {
                    new DriverDashboard(username);
                }

                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Login Details!");
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new LoginPage();
    }
}
