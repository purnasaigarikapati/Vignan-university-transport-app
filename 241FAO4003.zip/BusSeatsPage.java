package com.vignan.ui;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class BusSeatsPage extends JFrame {

    private Map<Integer, String> seatInfo = new HashMap<>();
    private Map<Integer, Boolean> seatReserved = new HashMap<>();
    private Map<Integer, String> seatCategory = new HashMap<>();
    private int totalSeats = 75;

    // Sample random names
    private String[] facultyNames = {"Dr. Sai", "Dr. Ravi", "Dr. Anjali", "Dr. Priya", "Dr. Kiran"};
    private String[] girlNames = {"Anjali", "Priya", "Neha", "Meera", "Sita", "Laxmi"};
    private String[] boyNames = {"Rohit", "Arjun", "Vikram", "Kiran", "Suresh", "Ajay"};
    private String[] otherNames = {"Alex", "John", "Maya", "Nina", "Nikhil"};

    public BusSeatsPage(String busNo) {
        setTitle("Bus Seats - " + busNo);
        setSize(750, 850);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());
        add(mainPanel);

        JLabel title = new JLabel("Bus Number: " + busNo, SwingConstants.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 18));
        title.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        mainPanel.add(title, BorderLayout.NORTH);

        JPanel seatPanel = new JPanel(new GridBagLayout());
        seatPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        mainPanel.add(new JScrollPane(seatPanel), BorderLayout.CENTER);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        Random rand = new Random();
        int seatNumber = 1;

        while (seatNumber <= totalSeats) {
            int row = (seatNumber - 1) / 5;

            // Left 2 seats
            for (int col = 0; col < 2 && seatNumber <= totalSeats; col++) {
                addSeatButton(seatPanel, gbc, row, col, seatNumber, rand);
                seatNumber++;
            }

            // Aisle gap column (col=2)

            // Right 3 seats
            for (int col = 0; col < 3 && seatNumber <= totalSeats; col++) {
                addSeatButton(seatPanel, gbc, row, col + 3, seatNumber, rand);
                seatNumber++;
            }
        }

        setVisible(true);
    }

    private void addSeatButton(JPanel panel, GridBagConstraints gbc, int row, int col, int seatNumber, Random rand) {
        String name;
        String category;

        if (seatNumber >= 1 && seatNumber <= 10) {
            name = facultyNames[rand.nextInt(facultyNames.length)];
            category = "Faculty";
        } else if (seatNumber >= 11 && seatNumber <= 50) {
            name = girlNames[rand.nextInt(girlNames.length)];
            category = "Girl";
        } else if (seatNumber >= 51 && seatNumber <= 70) {
            name = boyNames[rand.nextInt(boyNames.length)];
            category = "Boy";
        } else {
            name = otherNames[rand.nextInt(otherNames.length)];
            category = "Other";
        }

        String regNumber = "241FA" + String.format("%03d", rand.nextInt(999) + 1);
        seatInfo.put(seatNumber, "Name: " + name + "\nRegistration Number: " + regNumber);
        seatCategory.put(seatNumber, category);
        seatReserved.put(seatNumber, rand.nextBoolean());

        JButton seatBtn = new JButton(String.valueOf(seatNumber));
        seatBtn.setOpaque(true);
        seatBtn.setBorderPainted(false);
        updateSeatColor(seatNumber, seatBtn);

        final int sn = seatNumber;
        seatBtn.addActionListener(e -> {
            boolean reserved = seatReserved.get(sn);
            String cat = seatCategory.get(sn);
            if (reserved) {
                String info = seatInfo.get(sn);
                JOptionPane.showMessageDialog(this,
                        info + "\nCategory: " + cat + "\nStatus: Reserved",
                        "Seat " + sn,
                        JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this,
                        "Seat " + sn + " is Available (Not Reserved)\nCategory: " + cat,
                        "Seat " + sn,
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });

        gbc.gridx = col;
        gbc.gridy = row;
        panel.add(seatBtn, gbc);
    }

    private void updateSeatColor(int seatNumber, JButton seatBtn) {
        if (seatReserved.get(seatNumber)) {
            seatBtn.setBackground(Color.GREEN);
        } else {
            seatBtn.setBackground(Color.RED);
        }
        seatBtn.setForeground(Color.WHITE);
    }
}
