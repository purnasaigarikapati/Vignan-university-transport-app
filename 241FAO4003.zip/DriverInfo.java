package com.vignan.model;

public class DriverInfo {
    private String driverId;
    private String driverName;
    private String busNo;
    private int salary;
    private String morningTrip;
    private String eveningTrip;
    private int tripsPerDay;
    private int kmPerDay;

    public DriverInfo(String driverId, String driverName, String busNo, int salary,
                      String morningTrip, String eveningTrip, int tripsPerDay, int kmPerDay) {
        this.driverId = driverId;
        this.driverName = driverName;
        this.busNo = busNo;
        this.salary = salary;
        this.morningTrip = morningTrip;
        this.eveningTrip = eveningTrip;
        this.tripsPerDay = tripsPerDay;
        this.kmPerDay = kmPerDay;
    }

    public String getDriverId() { return driverId; }
    public String getDriverName() { return driverName; }
    public String getBusNo() { return busNo; }
    public int getSalary() { return salary; }
    public String getMorningTrip() { return morningTrip; }
    public String getEveningTrip() { return eveningTrip; }
    public int getTripsPerDay() { return tripsPerDay; }
    public int getKmPerDay() { return kmPerDay; }
}
