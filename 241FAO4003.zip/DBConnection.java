package com.vignan.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

    private static final String URL = 
        "jdbc:mysql://localhost:3306/vignan_bus";

    private static final String USER = "root";
    private static final String PASSWORD = "root";

    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("CONNECTED SUCCESSFULLY!");
            return conn;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("CONNECTION FAILED: " + e.getMessage());
            return null;
        }
    }
}