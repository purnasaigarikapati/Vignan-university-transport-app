package com.vignan.app;

import com.vignan.ui.LoginPage;

public class Main {
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(LoginPage::new);
    }
}
