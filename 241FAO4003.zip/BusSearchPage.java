package com.vignan.ui;

import com.vignan.db.DBConnection;
import com.vignan.model.Bus;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class BusSearchPage extends JFrame {

    private JTextField busField;
    private JTextArea resultArea;

    // Default constructor: open empty search window
    public BusSearchPage() {
        this(null, null);
    }

    // Constructor allowing a pre-filled busNo and external resultArea
    public BusSearchPage(String prefillBusNo, JTextArea externalResult) {
        setTitle("Search Bus");
        setSize(520, 420);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel header = new JLabel("Search Bus by Number", SwingConstants.CENTER);
        header.setBounds(0, 0, 520, 50);
        header.setOpaque(true);
        header.setBackground(new Color(18,61,140));
        header.setForeground(Color.WHITE);
        header.setFont(new Font("SansSerif", Font.BOLD, 18));
        add(header);

        JLabel lbl = new JLabel("Bus Number:");
        lbl.setBounds(40, 80, 120, 25);
        add(lbl);

        busField = new JTextField();
        busField.setBounds(160, 80, 220, 25);
        if (prefillBusNo != null) busField.setText(prefillBusNo);
        add(busField);

        JButton searchBtn = new JButton("Search");
        searchBtn.setBounds(200, 120, 100, 30);
        add(searchBtn);

        resultArea = (externalResult != null) ? externalResult : new JTextArea();
        if (externalResult == null) {
            resultArea.setBounds(40, 170, 420, 190);
            resultArea.setEditable(false);
            resultArea.setBorder(BorderFactory.createLineBorder(Color.GRAY));
            add(resultArea);
        }

        searchBtn.addActionListener(e -> searchBus());

        setVisible(true);
    }

    private void searchBus() {
        String busNo = busField.getText().trim().toUpperCase();
        if (busNo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter a bus number.");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM buses WHERE bus_no = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, busNo);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Bus b = new Bus(
                        rs.getString("bus_no"),
                        rs.getString("driver_name"),
                        rs.getString("driver_contact"),
                        rs.getString("location"),
                        rs.getString("start_time"),
                        rs.getString("leave_time")
                );

                StringBuilder sb = new StringBuilder();
                sb.append("Bus Number: ").append(b.getBusNo()).append("\n");
                sb.append("Driver Name: ").append(b.getDriverName()).append("\n");
                sb.append("Contact: ").append(b.getDriverContact()).append("\n");
                sb.append("Location: ").append(b.getLocation()).append("\n");
                sb.append("Starting Time: ").append(b.getStartTime()).append("\n");
                sb.append("Leaving Time: ").append(b.getLeaveTime()).append("\n");
                resultArea.setText(sb.toString());
            } else {
                resultArea.setText("No bus found with number: " + busNo);
            }
        } catch (Exception e) {
            resultArea.setText("DB Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
