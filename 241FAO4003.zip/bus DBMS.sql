CREATE DATABASE  vignan_bus;
USE vignan_bus;

CREATE TABLE users (
  username VARCHAR(50) PRIMARY KEY,
  password VARCHAR(100),
  role ENUM('Student','Driver','Faculty')
);

CREATE TABLE buses (
  bus_no VARCHAR(20) PRIMARY KEY,
  driver_name VARCHAR(100),
  driver_contact VARCHAR(20),
  location VARCHAR(100),
  start_time VARCHAR(20),
  leave_time VARCHAR(20)
);

CREATE TABLE driver_info (
  driver_id VARCHAR(20) PRIMARY KEY,
  driver_name VARCHAR(100),
  bus_no VARCHAR(20),
  salary INT,
  morning_trip VARCHAR(50),
  evening_trip VARCHAR(50),
  trips_per_day INT,
  km_per_day INT
);

-- sample rows
INSERT INTO users VALUES ('student1','pass123','Student');
INSERT INTO users VALUES ('driver_siva','driverpass','Driver');
INSERT INTO users VALUES ('faculty1','facpass','Faculty');

INSERT INTO buses VALUES ('AP39-4229','Siva','9876543218','Guntur','07:00','16:15');
insert into buses values('AP39-4228','naresh','6789054323','boys hostel','06:00','22:00'),
('AP39-4227','surya','6789054323','nallacheruvu','07:20','16:10'),
('AP39-4226','sai','6789054323','itc','06:50','16:18'),
('AP39-4225','babu','6789054323','lakshmipuram','07:00','16:11'),
('AP39-6195','chandra','6789054323','amaravathi','06:30','16:12'),
('AP39-6192','krishna','6789054323','bapatala','06:40','16:18'),
('AP39-2660','mali','6789054323','chilkaluripeta','06:10','16:23'),
('AP39-2658','sai ram','6789054323','tenali','07:10','16:10'),
('AP39-2657','krishna','6789054323','ponnur','07:00','16:10'),
('AP39-2655','teja','6789054323','vizawada','06:20','16:10'),
('AP39-2654','shaik mastain','6789054323','satanepalli','06:00','16:10'),
('AP39-2653','ravi','6789054323','snankarvillas','06:55','16:10'),
('AP39-2652','hali','6789054323','amaravathi road','06:59','16:10'),
('AP39-2651','rambo','6789054323','gorantla','06:54','16:10');
INSERT INTO buses VALUES ('AP39VB4229','Siva','9876543218','amarvathi road chilles','07:00','16:15');
INSERT INTO buses VALUES ('AP39VB4228','naresh','9876543218','boys hostel bus','07:00','16:15');
INSERT INTO buses VALUES ('AP39VB2660','saibabu','9456437893','chilkuluripeta','06:30','16:15');
iNSERT INTO buses VALUES ('AP39VB2658','nagababu','9456489893','nallacheruvu','07:00','16:15');
iNSERT INTO buses VALUES ('AP39VB2659','suresh','9456478893','nallapadu','07:00','16:15');
iNSERT INTO buses VALUES ('AP39VB2657','sai','9638567893','apakitala','07:00','16:15');
iNSERT INTO buses VALUES ('AP39VB2656','kiran','8938567893','ponnur','07:10','16:15');
iNSERT INTO buses VALUES ('AP07TM6192','harsha','8985567893','bapatla','06:20','16:15');
iNSERT INTO buses VALUES ('AP07TM6195','matiani hemanthpamulapadu','7894561233','amaravathi','06:20','16:15');




INSERT INTO driver_info VALUES ('D002','Siva','AP39VB4229',25000,'07:00-10:00','16:15-19:00',2,150);
INSERT INTO driver_info VALUES ('D003','saibabu','AP39VB2660',25000,'07:00-10:00','16:15-19:00',2,150);
CREATE TABLE bus_timetable (
    id INT AUTO_INCREMENT PRIMARY KEY,
    bus_no VARCHAR(20),
    trip_time VARCHAR(50),
    route VARCHAR(100)
);
INSERT INTO bus_timetable (bus_no, trip_time, route) VALUES
('AP39VB2660', '6:30 AM', 'Guntur → Vignan'),
('AP39VB2659', '5:00 PM', 'Vignan → Guntur'),
('AP39VB2658', '7:00 AM', 'Tenali → Vignan'),
('AP39VB2657', '4:45 PM', 'Vignan → Tenali');





