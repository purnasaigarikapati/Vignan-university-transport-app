package com.vignan.model;

public class Bus {
    private String busNo;
    private String driverName;
    private String driverContact;
    private String location;
    private String startTime;
    private String leaveTime;

    public Bus(String busNo, String driverName, String driverContact,
               String location, String startTime, String leaveTime) {
        this.busNo = busNo;
        this.driverName = driverName;
        this.driverContact = driverContact;
        this.location = location;
        this.startTime = startTime;
        this.leaveTime = leaveTime;
    }

    public String getBusNo() { return busNo; }
    public String getDriverName() { return driverName; }
    public String getDriverContact() { return driverContact; }
    public String getLocation() { return location; }
    public String getStartTime() { return startTime; }
    public String getLeaveTime() { return leaveTime; }
}
