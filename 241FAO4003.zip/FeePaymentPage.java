package com.vignan.ui;

import javax.swing.*;
import java.awt.*;
import java.net.URI;
import java.util.Arrays;
import java.util.Random;

public class FeePaymentPage extends JFrame {

    private final String UPI_ID = "vignan@upi";
    private final String PAYEE_NAME = "Vignan University";

    public FeePaymentPage() {
        setTitle("Online Fee Payment");
        setSize(520, 520);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel header = new JLabel("Online Fee Payment", SwingConstants.CENTER);
        header.setBounds(0, 0, 520, 50);
        header.setOpaque(true);
        header.setBackground(new Color(18, 61, 140));
        header.setForeground(Color.WHITE);
        header.setFont(new Font("SansSerif", Font.BOLD, 18));
        add(header);

        JLabel accLbl = new JLabel("<html><b>University Account No:</b> 123456789012</html>");
        accLbl.setBounds(30, 70, 380, 25);
        add(accLbl);

        JButton copyAcc = new JButton("Copy Account No");
        copyAcc.setBounds(360, 70, 140, 25);
        copyAcc.addActionListener(e -> {
            Toolkit.getDefaultToolkit().getSystemClipboard()
                    .setContents(new java.awt.datatransfer.StringSelection("123456789012"), null);
            JOptionPane.showMessageDialog(this, "Account number copied to clipboard.");
        });
        add(copyAcc);

        JLabel upiLbl = new JLabel("Pay via UPI:");
        upiLbl.setBounds(30, 125, 200, 25);
        add(upiLbl);

        // PHONEPE BUTTON
        JButton phonePeBtn = new JButton("PhonePe");
        phonePeBtn.setBounds(30, 165, 140, 40);
        phonePeBtn.addActionListener(e -> openUPILink("PHONEPE"));
        add(phonePeBtn);

        // GOOGLE PAY BUTTON
        JButton gpayBtn = new JButton("Google Pay");
        gpayBtn.setBounds(190, 165, 140, 40);
        gpayBtn.addActionListener(e -> openUPILink("GPAY"));
        add(gpayBtn);

        // PAYTM BUTTON
        JButton paytmBtn = new JButton("Paytm");
        paytmBtn.setBounds(350, 165, 120, 40);
        paytmBtn.addActionListener(e -> openUPILink("PAYTM"));
        add(paytmBtn);

        // OTHER UPI BUTTON
        JButton otherBtn = new JButton("Other UPI Apps");
        otherBtn.setBounds(150, 230, 200, 40);
        otherBtn.addActionListener(e -> showOtherUPIOptions());
        add(otherBtn);

        // ROUTE FEE BUTTON
        JButton routeBtn = new JButton("Show Bus Route Fee Details");
        routeBtn.setBounds(130, 310, 250, 40);
        routeBtn.addActionListener(e -> new RouteFeeWindow());
        add(routeBtn);

        setVisible(true);
    }

    // OTHER UPI OPTION POPUP
    private void showOtherUPIOptions() {
        String[] apps = {
                "Amazon Pay",
                "Flipkart UPI",
                "PayZapp",
                "PhonePe Lite",
                "Freecharge UPI",
                "Pop UPI",
                "SuperMoney UPI"
        };

        String selected = (String) JOptionPane.showInputDialog(
                this,
                "Select UPI App:",
                "Other UPI Methods",
                JOptionPane.PLAIN_MESSAGE,
                null,
                apps,
                apps[0]
        );

        if (selected != null) {
            openUPILink(selected);
        }
    }

    private void openUPILink(String app) {
        try {
            String amount = JOptionPane.showInputDialog(
                    this, "Enter Fee Amount (₹):", "30000");

            if (amount == null || amount.trim().isEmpty()) return;
            amount = amount.trim();

            String url = "";

            switch (app) {

                case "PHONEPE":
                    url = "https://upi.phonepe.com/pay?"
                            + "pa=" + UPI_ID
                            + "&pn=" + java.net.URLEncoder.encode(PAYEE_NAME, "UTF-8")
                            + "&am=" + amount
                            + "&cu=INR";
                    break;

                case "GPAY":
                    url = "upi://pay?"
                            + "pa=" + UPI_ID
                            + "&pn=" + PAYEE_NAME
                            + "&am=" + amount
                            + "&cu=INR";
                    break;

                case "PAYTM":
                    url = "paytmmp://pay?"
                            + "pa=" + UPI_ID
                            + "&pn=" + PAYEE_NAME
                            + "&am=" + amount
                            + "&cu=INR";
                    break;

                // OTHER UPI APPS
                default:
                    url = "upi://pay?"
                            + "pa=" + UPI_ID
                            + "&pn=" + PAYEE_NAME
                            + "&am=" + amount
                            + "&cu=INR";
                    break;
            }

            Desktop.getDesktop().browse(new URI(url));

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Unable to open UPI app.\nError: " + ex.getMessage());
        }
    }
}

class RouteFeeWindow extends JFrame {

    public RouteFeeWindow() {
        setTitle("Bus Route Fee Details");
        setSize(400, 350);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        String[] routes = {
                "Guntur", "Amaravathi", "Tenali", "Vijayawada",
                "Chilakaluripet", "Sattenapalli", "Peracherla", "Narasaraopeta"
        };

        Arrays.sort(routes);

        Random rand = new Random();
        String[][] data = new String[routes.length][2];

        for (int i = 0; i < routes.length; i++) {
            data[i][0] = routes[i];
            data[i][1] = "₹" + (30000 + rand.nextInt(20001));
        }

        String[] columns = {"City / Route", "Fee"};

        JTable table = new JTable(data, columns);
        table.setRowHeight(28);

        add(new JScrollPane(table), BorderLayout.CENTER);
        setVisible(true);
    }
}
